package cn.foxie.paypet;
import android.app.*;
import android.content.*;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.time.*;
import java.util.Locale;
import java.util.Random;

public class Pet extends Service {
    WindowManager wm; WindowManager.LayoutParams pos; LinearLayout card;
    TextView fox,total,words; Handler handler=new Handler(Looper.getMainLooper());
    final Random rng=new Random(); long lastMinute=-1; int tip;
    String[] tips={"刚刚那一分，姓沐。","你喝口水，工资也在走。","又攒下一口拿铁。","金币归咱家。"};
    int dp(int n){return Math.round(getResources().getDisplayMetrics().density*n);}
    public IBinder onBind(Intent i){return null;}
    public int onStartCommand(Intent i,int f,int id){
        if(!Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY;}
        NotificationManager nm=getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("pet","桌宠运行",NotificationManager.IMPORTANCE_LOW));
        PendingIntent settings=PendingIntent.getActivity(this,0,new Intent(this,Home.class),PendingIntent.FLAG_IMMUTABLE);
        startForeground(1,new Notification.Builder(this,"pet").setSmallIcon(android.R.drawable.star_on).setContentTitle("狐狸小金库").setContentText("点此调整薪资或收起桌宠").setContentIntent(settings).build());
        if(card==null)show();return START_NOT_STICKY;
    }
    TextView add(int size){TextView t=new TextView(this);t.setTextSize(size);t.setTextColor(0xffffd589);card.addView(t);return t;}
    void show(){
        wm=getSystemService(WindowManager.class);card=new LinearLayout(this);card.setOrientation(1);card.setGravity(Gravity.CENTER);card.setPadding(dp(9),dp(4),dp(9),dp(4));
        GradientDrawable bg=new GradientDrawable();bg.setColor(0xeb651e35);bg.setCornerRadius(dp(18));card.setBackground(bg);
        fox=add(28);fox.setText("🦊");total=add(13);words=add(12);words.setVisibility(View.GONE);
        pos=new WindowManager.LayoutParams(-2,-2,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        pos.gravity=Gravity.TOP|Gravity.LEFT;pos.x=dp(8);pos.y=dp(180);
        card.setOnTouchListener(new View.OnTouchListener(){
            float x,y;int left,top;boolean drag;
            public boolean onTouch(View v,MotionEvent e){
                float dx=e.getRawX()-x,dy=e.getRawY()-y;
                switch(e.getActionMasked()){
                case MotionEvent.ACTION_DOWN:x=e.getRawX();y=e.getRawY();left=pos.x;top=pos.y;drag=false;return true;
                case MotionEvent.ACTION_MOVE:
                    if(Math.hypot(dx,dy)>ViewConfiguration.get(Pet.this).getScaledTouchSlop())drag=true;
                    if(drag){android.graphics.Point bounds=new android.graphics.Point();wm.getDefaultDisplay().getSize(bounds);
                    pos.x=Math.max(0,Math.min(bounds.x-card.getWidth(),left+(int)dx));pos.y=Math.max(0,Math.min(bounds.y-card.getHeight(),top+(int)dy));wm.updateViewLayout(card,pos);}return true;
                case MotionEvent.ACTION_UP:if(!drag)coin();return true;
                default:return true;}
            }
        });
        wm.addView(card,pos);tick.run();
    }
    final Runnable hide=()->{fox.setText("🦊");words.setVisibility(View.GONE);};
    void coin(){fox.setText("🦊 🪙");words.setVisibility(View.VISIBLE);fox.setTranslationY(dp(4));fox.animate().translationY(-dp(3)).setDuration(200).withEndAction(()->fox.animate().translationY(0).setDuration(180)).start();handler.removeCallbacks(hide);handler.postDelayed(hide,3500);}
    int seconds(SharedPreferences p,String k,String def){return LocalTime.parse(p.getString(k,def)).toSecondOfDay();}
    final Runnable tick=new Runnable(){public void run(){
        SharedPreferences p=getSharedPreferences("pet",0);LocalDateTime d=LocalDateTime.now();int n=d.toLocalTime().toSecondOfDay();
        int a=seconds(p,"start","09:00"),b=seconds(p,"lunch","12:00"),c=seconds(p,"back","13:00"),e=seconds(p,"end","18:00");
        boolean work=!p.getBoolean("weekdays",true)||d.getDayOfWeek().getValue()<=5;
        int s=work?Math.max(0,Math.min(n,b)-a)+Math.max(0,Math.min(n,e)-c):0;
        double amount=Double.parseDouble(p.getString("salary","0"))/Double.parseDouble(p.getString("days","22"))*s/(b-a+e-c);
        total.setText(String.format(Locale.CHINA,"¥%,.2f",amount));
        long minute=System.currentTimeMillis()/60000;if(minute!=lastMinute){tip=rng.nextInt(tips.length);lastMinute=minute;}
        String line=work && n>=e-300 && n<e?"流水哗啦啦，木木要回家。\n工时滴答答，金币归咱家。🦊🪙":!work?"今天的时间归小狐狸。":n>=e?"今日封账，下班快乐。":tips[tip];
        words.setText(String.format(Locale.CHINA,"%02d:%02d:%02d\n%s",s/3600,s/60%60,s%60,line));
        handler.postDelayed(this,1000-System.currentTimeMillis()%1000);
    }};
    public void onDestroy(){handler.removeCallbacksAndMessages(null);if(card!=null){wm.removeView(card);card=null;}super.onDestroy();}
}
