使用 Android Studio 打开本文件夹，以 JDK 17、Gradle 8.9、Android SDK 35 构建。命令为 gradle :app:assembleDebug。APK 输出到 app/build/outputs/apk/debug。安装后打开狐狸小金库，输入月薪、同日排班，授权显示在其他应用上层，再放出狐狸。
