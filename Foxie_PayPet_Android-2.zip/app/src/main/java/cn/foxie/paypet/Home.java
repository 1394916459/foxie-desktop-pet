package cn.foxie.paypet;
import android.app.*;
import android.os.*;
import android.content.*;
import android.provider.Settings;
import android.net.Uri;
import android.widget.*;
import java.time.LocalTime;

public class Home extends Activity {
    final String[] keys={"salary","days","start","lunch","back","end"};
    final String[] labels={"月薪（元）","月计薪天数","上班","午休开始","午休结束","下班"};
    final String[] defaults={"","22","09:00","12:00","13:00","18:00"};
    EditText[] inputs=new EditText[6];
    TextView status;
    CheckBox weekdays;
    public void onCreate(Bundle state){
        super.onCreate(state);
        ScrollView scroll=new ScrollView(this);
        LinearLayout layout=new LinearLayout(this); layout.setOrientation(1);
        layout.setPadding(38,70,38,60); scroll.addView(layout);setContentView(scroll);
        TextView heading=new TextView(this);heading.setText("日进斗金 · 1.4");heading.setTextSize(27);layout.addView(heading);
        SharedPreferences p=getSharedPreferences("pet",0);
        for(int i=0;i<6;i++){
            TextView title=new TextView(this);title.setText(labels[i]);layout.addView(title);
            inputs[i]=new EditText(this);inputs[i].setSingleLine();if(i<2)inputs[i].setInputType(8194);
            inputs[i].setText(p.getString(keys[i],defaults[i]));layout.addView(inputs[i]);
        }
        weekdays=new CheckBox(this);weekdays.setText("仅周一至周五计薪");weekdays.setChecked(p.getBoolean("weekdays",true));layout.addView(weekdays);
        status=new TextView(this);layout.addView(status);
        Button start=new Button(this);start.setText("保存并放出小狐狸");layout.addView(start);start.setOnClickListener(v->activate());
        Button stop=new Button(this);stop.setText("收起桌宠");layout.addView(stop);stop.setOnClickListener(v->{stopService(new Intent(this,Pet.class));status.setText("小狐狸已收起");});
    }
    void activate(){
        String[] values=new String[6];for(int i=0;i<6;i++)values[i]=inputs[i].getText().toString().trim();
        try{
            double pay=Double.parseDouble(values[0]),days=Double.parseDouble(values[1]);
            if(!(pay>0 && pay<=99999999 && days>=1 && days<=31))throw new IllegalArgumentException();
            int[] t=new int[4];for(int i=0;i<4;i++)t[i]=LocalTime.parse(values[i+2]).toSecondOfDay();
            if(t[0]>t[1]||t[1]>t[2]||t[2]>t[3]||t[3]-t[2]+t[1]-t[0]<=0)throw new IllegalArgumentException();
        }catch(RuntimeException e){status.setText("请核对月薪、计薪天数和同日班次。时间填 09:00 这样的格式。");return;}
        SharedPreferences.Editor edit=getSharedPreferences("pet",0).edit();
        for(int i=0;i<6;i++)edit.putString(keys[i],values[i]);edit.putBoolean("weekdays",weekdays.isChecked()).apply();
        if(!Settings.canDrawOverlays(this)){
            status.setText("允许本应用显示在其他应用上层后，返回再点放出。");
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));return;
        }
        startForegroundService(new Intent(this,Pet.class));status.setText("可返回桌面。拖动换位置，轻点展开工作日历、看金币。");
    }
}
