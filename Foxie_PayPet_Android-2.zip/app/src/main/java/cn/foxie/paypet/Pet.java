package cn.foxie.paypet;
import android.app.*;
import android.content.*;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.time.*;
import java.util.Locale;
import java.util.Random;

public class Pet extends Service {
    WindowManager wm; WindowManager.LayoutParams pos; LinearLayout card;
    ImageView fox; TextView total,words,status; ProgressBar progress; boolean expanded; Handler handler=new Handler(Looper.getMainLooper());
    final Random rng=new Random(); long lastMinute=-1; int tip;
    String[] tips={"刚刚那一分，姓沐。","你喝口水，工资也在走。","又攒下一口拿铁。","流水哗啦啦，木木要回家。\n工时滴答答，金币归咱家。"};
    FrameLayout scene;
    LinearLayout details, week;
    TextView stamp, rates, paid, weekend;
    TextView[] dates=new TextView[7];
    LocalDate shown;
    long nextBurst;
    TextView panelText(LinearLayout parent,int size,int color){
        TextView view=new TextView(this);
        view.setTextSize(size);view.setTextColor(color);parent.addView(view);return view;
    }
    GradientDrawable tile(int fill,int radius){
        GradientDrawable shape=new GradientDrawable();shape.setColor(fill);shape.setCornerRadius(dp(radius));return shape;
    }
    void calendarPanel(){
        details=new LinearLayout(this);details.setOrientation(1);
        details.setPadding(dp(9),dp(8),dp(9),dp(8));
        details.setBackground(tile(0xfff6e9d3,12));card.addView(details);
        stamp=panelText(details,15,0xff52283b);
        week=new LinearLayout(this);details.addView(week);
        for(int i=0;i<7;i++){
            TextView date=new TextView(this);date.setTextSize(12);date.setGravity(Gravity.CENTER);
            date.setPadding(dp(3),dp(4),dp(3),dp(4));
            week.addView(date,new LinearLayout.LayoutParams(0,-2,1));dates[i]=date;
        }
        rates=panelText(details,13,0xff63384a);
        paid=panelText(details,13,0xff63384a);
        weekend=panelText(details,14,0xff803915);
        details.setVisibility(View.GONE);
    }
    void setWeek(LocalDate day){
        if(day.equals(shown))return;
        shown=day;int index=day.getDayOfWeek().getValue()-1;
        stamp.setText(String.format(Locale.CHINA,"%d年%d月 · 工作日历",day.getYear(),day.getMonthValue()));
        LocalDate monday=day.minusDays(index);
        for(int i=0;i<7;i++){
            dates[i].setText("一二三四五六日".substring(i,i+1)+"\n"+monday.plusDays(i).getDayOfMonth());
            dates[i].setTextColor(i==index?0xffffffff:0xff583e40);
            dates[i].setBackground(tile(i==index?0xff924361:0x00000000,8));
        }
    }
    void burst(){
        for(int i=0;i<5;i++){
            TextView coin=new TextView(this);coin.setText("¥");coin.setTextSize(9);
            coin.setGravity(Gravity.CENTER);coin.setTextColor(0xff784116);coin.setBackground(tile(0xffffd260,9));
            FrameLayout.LayoutParams place=new FrameLayout.LayoutParams(dp(14),dp(14),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
            scene.addView(coin,place);
            coin.animate().translationX(dp((i-2)*16)).translationY(-dp(18+rng.nextInt(15)))
                .alpha(0).setStartDelay(i*45L).setDuration(820).withEndAction(()->scene.removeView(coin)).start();
        }
    }
    int dp(int n){return Math.round(getResources().getDisplayMetrics().density*n);}
    public IBinder onBind(Intent i){return null;}
    public int onStartCommand(Intent i,int f,int id){
        if(!Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY;}
        NotificationManager nm=getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("pet","桌宠运行",NotificationManager.IMPORTANCE_LOW));
        PendingIntent settings=PendingIntent.getActivity(this,0,new Intent(this,Home.class),PendingIntent.FLAG_IMMUTABLE);
        startForeground(1,new Notification.Builder(this,"pet").setSmallIcon(android.R.drawable.star_on).setContentTitle("日进斗金").setContentText("点此调整薪资或收起桌宠").setContentIntent(settings).build());
        if(card==null)show();return START_NOT_STICKY;
    }
    TextView add(int size){TextView t=new TextView(this);t.setTextSize(size);t.setTextColor(0xffffd589);card.addView(t);return t;}
    void show(){
        wm=getSystemService(WindowManager.class);card=new LinearLayout(this);card.setOrientation(1);card.setGravity(Gravity.CENTER);card.setPadding(dp(9),dp(4),dp(9),dp(4));
        GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xfa552639,0xfa311b2b});
        bg.setCornerRadius(dp(18));bg.setStroke(dp(1),0xffcf9955);card.setBackground(bg);
        card.setPadding(dp(12),dp(7),dp(12),dp(8));
        fox=new ImageView(this);fox.setImageResource(R.drawable.gilt_fox);
        scene=new FrameLayout(this);card.addView(scene,new LinearLayout.LayoutParams(dp(94),dp(48)));
        scene.addView(fox,new FrameLayout.LayoutParams(-1,-1));
        TextView glint=new TextView(this);glint.setText("✦");glint.setTextColor(0xffffefac);glint.setTextSize(14);
        scene.addView(glint,new FrameLayout.LayoutParams(dp(17),dp(22),Gravity.TOP|Gravity.RIGHT));
        android.view.animation.AlphaAnimation shimmer=new android.view.animation.AlphaAnimation(0.12f,1f);
        shimmer.setDuration(1600);shimmer.setRepeatMode(2);shimmer.setRepeatCount(-1);glint.startAnimation(shimmer);
        add(11).setText("今日已赚");total=add(22);total.setTypeface(android.graphics.Typeface.SERIF,1);
        status=add(12);progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        progress.setMax(1000);progress.setProgressTintList(android.content.res.ColorStateList.valueOf(0xffffc55b));
        card.addView(progress,new LinearLayout.LayoutParams(dp(135),dp(6)));
        calendarPanel();words=add(12);words.setGravity(Gravity.CENTER);words.setVisibility(View.GONE);
        pos=new WindowManager.LayoutParams(-2,-2,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        pos.gravity=Gravity.TOP|Gravity.LEFT;pos.x=dp(8);pos.y=dp(180);
        card.setOnTouchListener(new View.OnTouchListener(){
            float x,y;int left,top;boolean drag;
            public boolean onTouch(View v,MotionEvent e){
                float dx=e.getRawX()-x,dy=e.getRawY()-y;
                switch(e.getActionMasked()){
                case MotionEvent.ACTION_DOWN:x=e.getRawX();y=e.getRawY();left=pos.x;top=pos.y;drag=false;return true;
                case MotionEvent.ACTION_MOVE:
                    if(Math.hypot(dx,dy)>ViewConfiguration.get(Pet.this).getScaledTouchSlop())drag=true;
                    if(drag){android.graphics.Point bounds=new android.graphics.Point();wm.getDefaultDisplay().getSize(bounds);
                    pos.x=Math.max(0,Math.min(bounds.x-card.getWidth(),left+(int)dx));pos.y=Math.max(0,Math.min(bounds.y-card.getHeight(),top+(int)dy));wm.updateViewLayout(card,pos);}return true;
                case MotionEvent.ACTION_UP:if(!drag)coin();return true;
                default:return true;}
            }
        });
        wm.addView(card,pos);tick.run();
    }
    void coin(){
        expanded=!expanded;details.setVisibility(expanded?View.VISIBLE:View.GONE);burst();
        words.setVisibility(expanded?View.VISIBLE:View.GONE);
        fox.animate().cancel();fox.setRotation(-6);fox.animate().rotation(0).setDuration(360).start();
        android.graphics.Point bounds=new android.graphics.Point();wm.getDefaultDisplay().getSize(bounds);
        card.measure(View.MeasureSpec.makeMeasureSpec(bounds.x,View.MeasureSpec.AT_MOST),
                     View.MeasureSpec.makeMeasureSpec(bounds.y,View.MeasureSpec.AT_MOST));
        pos.x=Math.max(0,Math.min(pos.x,bounds.x-card.getMeasuredWidth()));
        pos.y=Math.max(0,Math.min(pos.y,bounds.y-card.getMeasuredHeight()));
        wm.updateViewLayout(card,pos);
    }
    String clock(int s){return String.format(Locale.CHINA,"%02d:%02d:%02d",s/3600,s/60%60,s%60);}
    int seconds(SharedPreferences p,String k,String def){return LocalTime.parse(p.getString(k,def)).toSecondOfDay();}
    final Runnable tick=new Runnable(){public void run(){
        SharedPreferences p=getSharedPreferences("pet",0);LocalDateTime d=LocalDateTime.now();int n=d.toLocalTime().toSecondOfDay();
        int a=seconds(p,"start","09:00"),b=seconds(p,"lunch","12:00"),c=seconds(p,"back","13:00"),e=seconds(p,"end","18:00");
        boolean work=!p.getBoolean("weekdays",true)||d.getDayOfWeek().getValue()<=5;
        int s=work?Math.max(0,Math.min(n,b)-a)+Math.max(0,Math.min(n,e)-c):0;
        double amount=Double.parseDouble(p.getString("salary","0"))/Double.parseDouble(p.getString("days","22"))*s/(b-a+e-c);
        total.setText(String.format(Locale.CHINA,"¥%,.2f",amount));
        long minute=System.currentTimeMillis()/60000;if(minute!=lastMinute){tip=rng.nextInt(tips.length);lastMinute=minute;}
        String line=work && n>=e-300 && n<e?"流水哗啦啦，木木要回家。\n工时滴答答，金币归咱家。🦊🪙":!work?"今天的时间归小狐狸。":n>=e?"今日封账，下班快乐。":tips[tip];
        int duration=b-a+e-c;
        double daily=Double.parseDouble(p.getString("salary","0"))/Double.parseDouble(p.getString("days","22"));
        double rate=daily/duration;
        total.setContentDescription("今日已赚"+total.getText());
        progress.setProgress(Math.round(1000f*s/duration));
        status.setText(!work?"休息日 · 时间归你":n<a?"距开工 "+clock(a-n):n>=e?"今日收工 · 100%":"距下班 "+clock(e-n));
        setWeek(d.toLocalDate());
        rates.setText(String.format(Locale.CHINA,"每秒 ¥%.5f   ·   时薪 ¥%.2f",rate,rate*3600));
        paid.setText(String.format(Locale.CHINA,"日薪 ¥%.2f   ·   已计薪 %s",daily,clock(s)));
        weekend.setVisibility(p.getBoolean("weekdays",true)?View.VISIBLE:View.GONE);
        LocalDateTime friday=d.toLocalDate().plusDays(5-d.getDayOfWeek().getValue()).atTime(LocalTime.ofSecondOfDay(e));
        long left=Math.max(0,Duration.between(d,friday).getSeconds());
        weekend.setText(left==0?"周末时间归你":String.format(Locale.CHINA,"距周末 %d天 %s",left/86400,clock((int)(left%86400))));
        words.setText(line);
        boolean earning=work && rate>0 && ((n>=a && n<b)||(n>=c && n<e));
        long now=SystemClock.elapsedRealtime();
        if(!earning)nextBurst=0;
        else if(nextBurst==0)nextBurst=now+4000;
        else if(now>=nextBurst){burst();nextBurst=now+12000+rng.nextInt(9001);}
        handler.postDelayed(this,1000-System.currentTimeMillis()%1000);
    }};
    public void onDestroy(){handler.removeCallbacksAndMessages(null);if(card!=null){wm.removeView(card);card=null;}super.onDestroy();}
}
